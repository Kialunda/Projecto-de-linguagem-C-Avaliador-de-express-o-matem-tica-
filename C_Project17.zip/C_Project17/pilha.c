#include <stdlib.h>
#include "Pilha.h"

Pilha* pilha_cria() {
    Pilha *p = (Pilha*) malloc(sizeof(Pilha));
    p->topo = NULL;
    return p;
}

void pilha_push(Pilha *p, char v) {
    No *n = (No*) malloc(sizeof(No));
    n->info = v;
    n->prox = p->topo;
    p->topo = n;
}

char pilha_pop(Pilha *p) {
    if (p->topo == NULL) return '\0';
    No *n = p->topo;
    char v = n->info;
    p->topo = n->prox;
    free(n);
    return v;
}

char pilha_topo(Pilha *p) {
    if (p->topo == NULL) return '\0';
    return p->topo->info;
}

int pilha_vazia(Pilha *p) {
    return (p->topo == NULL);
}

void pilha_libera(Pilha *p) {
    while (!pilha_vazia(p)) {
        pilha_pop(p);
    }
    free(p);
}
