#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "analisador.h"

int main() {
    FILE *in = fopen("in.txt", "r");
    FILE *out = fopen("out.txt", "w");

    if (!in || !out) {
        printf("Erro ao abrir arquivos.\n");
        return 1;
    }

    char linha[256];
    while (fgets(linha, sizeof(linha), in)) {
        char resultado[256];
        if (avaliar_expressao(linha, resultado)) {
            fprintf(out, "%s\n", resultado);
        } else {
            fprintf(out, "%s\n", resultado);
        }
    }

    fclose(in);
    fclose(out);
    return 0;
}
