#include <stdlib.h>
#include "Pilha_int.h"

Pilha_int* pilha_int_cria() {
    Pilha_int *p = (Pilha_int*) malloc(sizeof(Pilha_int));
    p->topo = NULL;
    return p;
}

void pilha_int_push(Pilha_int *p, int v) {
    NoInt *n = (NoInt*) malloc(sizeof(NoInt));
    n->info = v;
    n->prox = p->topo;
    p->topo = n;
}

int pilha_int_pop(Pilha_int *p) {
    if (p->topo == NULL) return 0;
    NoInt *n = p->topo;
    int v = n->info;
    p->topo = n->prox;
    free(n);
    return v;
}

int pilha_int_topo(Pilha_int *p) {
    if (p->topo == NULL) return 0;
    return p->topo->info;
}

int pilha_int_vazia(Pilha_int *p) {
    return (p->topo == NULL);
}

void pilha_int_libera(Pilha_int *p) {
    while (!pilha_int_vazia(p)) {
        pilha_int_pop(p);
    }
    free(p);
}
