#ifndef PILHA_INT_H
#define PILHA_INT_H

typedef struct no_int {
    int info;
    struct no_int *prox;
} NoInt;

typedef struct {
    NoInt *topo;
} Pilha_int;

Pilha_int* pilha_int_cria();
void pilha_int_push(Pilha_int *p, int v);
int pilha_int_pop(Pilha_int *p);
int pilha_int_topo(Pilha_int *p);
int pilha_int_vazia(Pilha_int *p);
void pilha_int_libera(Pilha_int *p);

#endif
