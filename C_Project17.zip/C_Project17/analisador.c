#include <string.h>
#include <stdio.h>
#include "analisador.h"
#include "lexer.h"
#include "parser.h"
#include "evaluator.h"

int avaliar_expressao(const char *expr, char *saida) {
    Token tokens[100];
    int erro_lex;

    // Etapa 1: análise léxica (tokenização)
    int n = tokenize(expr, tokens, &erro_lex);
    if (erro_lex) {
        strcpy(saida, "Erro: Caracteres inválidos");
        return 0;
    }

    // Etapa 2: análise sintática (parser -> RPN)
    Token posfixa[100];
    int erro_parse;
    int m = shunting_yard(tokens, n, posfixa, &erro_parse);
    if (erro_parse) {
        strcpy(saida, "Erro: Parênteses desbalanceados");
        return 0;
    }

    // Etapa 3: avaliação da expressão pós-fixada
    int erro_div;
    int resultado = avaliar_posfixa(posfixa, m, &erro_div);
    if (erro_div) {
        strcpy(saida, "Erro: Divisão por zero");
        return 0;
    }

    // Resultado numérico final
    sprintf(saida, "%d", resultado);
    return 1;
}
