#ifndef EVALUATOR_H
#define EVALUATOR_H

#include "lexer.h"

int avaliar_posfixa(Token posfixa[], int n, int *div_zero);

#endif
