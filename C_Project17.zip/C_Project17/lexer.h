#ifndef LEXER_H
#define LEXER_H

// Tipos de tokens possíveis na expressão
typedef enum {
    NUMERO,
    OPERADOR,
    PARENTESE_ABRE,
    PARENTESE_FECHA,
    INVALIDO,
    NONE  // usado como "token vazio" se necessário
} TipoToken;

// Um token representa uma unidade da expressão (ex: "2", "+", "(")
typedef struct {
    TipoToken tipo;
    char valor[10];  // Ex: "5", "+", "("
} Token;

// Função que transforma a string de expressão em uma lista de tokens
int tokenize(const char *expr, Token tokens[], int *erro);

#endif
