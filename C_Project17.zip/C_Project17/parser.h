#ifndef PARSER_H
#define PARSER_H

#include "lexer.h"

int shunting_yard(Token tokens[], int n, Token saida[], int *erro);

#endif
