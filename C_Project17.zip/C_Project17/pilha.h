#ifndef PILHA_H
#define PILHA_H

typedef struct no {
    char info;
    struct no *prox;
} No;

typedef struct {
    No *topo;
} Pilha;

Pilha* pilha_cria();
void pilha_push(Pilha *p, char v);
char pilha_pop(Pilha *p);
char pilha_topo(Pilha *p);
int pilha_vazia(Pilha *p);
void pilha_libera(Pilha *p);

#endif
