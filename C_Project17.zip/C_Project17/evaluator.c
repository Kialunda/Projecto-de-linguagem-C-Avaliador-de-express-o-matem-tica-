#include <stdlib.h>
#include "evaluator.h"
#include "Pilha_int.h"

int avaliar_posfixa(Token posfixa[], int n, int *div_zero) {
    Pilha_int *valores = pilha_int_cria();
    *div_zero = 0;

    for (int i = 0; i < n; i++) {
        if (posfixa[i].tipo == NUMERO) {
            // Agora usando atoi para lidar com múltiplos dígitos
            int num = atoi(posfixa[i].valor);
            pilha_int_push(valores, num);
        } else if (posfixa[i].tipo == OPERADOR) {
            int b = pilha_int_pop(valores);
            int a = pilha_int_pop(valores);
            int r = 0;

            switch (posfixa[i].valor[0]) {
                case '+': r = a + b; break;
                case '-': r = a - b; break;
                case '*': r = a * b; break;
                case '/':
                    if (b == 0) {
                        *div_zero = 1;
                        pilha_int_libera(valores);
                        return 0;
                    }
                    r = a / b;
                    break;
                case '^':
                    r = 1;
                    for (int k = 0; k < b; k++) r *= a;
                    break;
            }

            pilha_int_push(valores, r);
        }
    }

    int resultado = pilha_int_pop(valores);
    pilha_int_libera(valores);
    return resultado;
}
s);
    pilha_int_libera(valores);
    return resultado;
}
