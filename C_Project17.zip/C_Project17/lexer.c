#include <ctype.h>
#include <string.h>
#include "lexer.h"

int eh_operador(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

int tokenize(const char *expr, Token tokens[], int *erro) {
    int i = 0, j = 0;
    *erro = 0;

    while (expr[i] != '\0' && expr[i] != '\n') {
        if (isspace(expr[i])) {
            i++;
        } else if (isdigit(expr[i])) {
            tokens[j].tipo = NUMERO;
            int k = 0;

            // Aceita números com mais de 1 dígito
            while (isdigit(expr[i])) {
                tokens[j].valor[k++] = expr[i++];
            }

            tokens[j].valor[k] = '\0';
            j++;
        } else if (eh_operador(expr[i])) {
            tokens[j].tipo = OPERADOR;
            tokens[j].valor[0] = expr[i];
            tokens[j].valor[1] = '\0';
            j++;
            i++;
        } else if (expr[i] == '(') {
            tokens[j].tipo = PARENTESE_ABRE;
            tokens[j].valor[0] = '(';
            tokens[j].valor[1] = '\0';
            j++;
            i++;
        } else if (expr[i] == ')') {
            tokens[j].tipo = PARENTESE_FECHA;
            tokens[j].valor[0] = ')';
            tokens[j].valor[1] = '\0';
            j++;
            i++;
        } else {
            *erro = 1;
            return 0;
        }
    }

    return j;
}
