#include <string.h>
#include "parser.h"
#include "Pilha.h"

int precedencia(char op) {
    switch (op) {
        case '^': return 3;
        case '*':
        case '/': return 2;
        case '+':
        case '-': return 1;
        default: return 0;
    }
}

int associatividade_direita(char op) {
    return op == '^';
}

int eh_operador(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

int shunting_yard(Token tokens[], int n, Token saida[], int *erro) {
    Pilha *pilha = pilha_cria();
    int j = 0;
    *erro = 0;

    for (int i = 0; i < n; i++) {
        if (tokens[i].tipo == NUMERO) {
            saida[j++] = tokens[i];
        } else if (tokens[i].tipo == OPERADOR) {
            while (!pilha_vazia(pilha)) {
                char topo = pilha_topo(pilha);
                if (eh_operador(topo) &&
                    ((associatividade_direita(tokens[i].valor[0]) == 0 && precedencia(tokens[i].valor[0]) <= precedencia(topo)) ||
                     (associatividade_direita(tokens[i].valor[0]) == 1 && precedencia(tokens[i].valor[0]) < precedencia(topo)))) {
                    Token op;
                    op.tipo = OPERADOR;
                    op.valor[0] = pilha_pop(pilha);
                    op.valor[1] = '\0';
                    saida[j++] = op;
                } else {
                    break;
                }
            }
            pilha_push(pilha, tokens[i].valor[0]);
        } else if (tokens[i].tipo == PARENTESE_ABRE) {
            pilha_push(pilha, '(');
        } else if (tokens[i].tipo == PARENTESE_FECHA) {
            int fechado = 0;
            while (!pilha_vazia(pilha)) {
                char topo = pilha_pop(pilha);
                if (topo == '(') {
                    fechado = 1;
                    break;
                }
                Token op;
                op.tipo = OPERADOR;
                op.valor[0] = topo;
                op.valor[1] = '\0';
                saida[j++] = op;
            }
            if (!fechado) {
                *erro = 1; // parênteses desbalanceados
                pilha_libera(pilha);
                return 0;
            }
        }
    }

    while (!pilha_vazia(pilha)) {
        char topo = pilha_pop(pilha);
        if (topo == '(') {
            *erro = 1;
            pilha_libera(pilha);
            return 0;
        }
        Token op;
        op.tipo = OPERADOR;
        op.valor[0] = topo;
        op.valor[1] = '\0';
        saida[j++] = op;
    }

    pilha_libera(pilha);
    return j;
}
