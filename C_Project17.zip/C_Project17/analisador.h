#ifndef ANALISADOR_H
#define ANALISADOR_H

int avaliar_expressao(const char *expr, char *saida);

#endif
